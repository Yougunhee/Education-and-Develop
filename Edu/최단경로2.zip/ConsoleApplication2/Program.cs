﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static int[,] array = new int[10, 10];
        static bool ch=false;

        public static void check(int x, int y, int a)
        {
            array[x, y] = 1;
            if ((x == a - 1) && (y == a - 1))
            {
                ch = true;
                return;
            }
            if ((y!=a-1)&&(array[x, y+1] == 0))
            {
                y += 1;
                check(x, y, a);
                y -= 1;
            }
            if ((x!=a-1)&&(array[x + 1, y] == 0))
            {
                x += 1;
                check(x, y, a);
                x -= 1;
            }
            if ((y != 0)&&(array[x, y - 1] == 0))
            {
                y -= 1;
               check(x, y, a);
                y += 1;
            }
            if ((x != 0)&&(array[x - 1, y] == 0))
            {
                x -= 1;
                check(x, y, a);
                x += 1;
            }
            array[x, y] = 0;
        }

        static void Main(string[] args)
        {
            int a = Convert.ToInt32(Console.ReadLine());
            int i, j;
            int x=0, y=0;
            int count = 0;
            for (i = 0; i < 10; i++)
            {
                for (j = 0; j < 10; j++)
                {
                    array[i, j] = 1;
                }
            }
            for (i = 0; i < a; i++)
            {
                for (j = 0; j < a; j++)
                {
                    array[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            for (i = 0; i < a; i++)
            {
                for (j = 0; j < a; j++)
                {
                    Console.Write(array[i,j]);
                }
                Console.Write("\n");
            }
            check(x, y, a);
            if (ch==true) Console.WriteLine("O");
            else Console.WriteLine("X");
        }
    }
}
