﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FregicEdu
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            if (Check1.IsChecked == true)
            {
                TBlock1.Text = "잘생긴" + TBox1.Text;
            }
            else
            {
                TBlock1.Text = TBox1.Text;
            }
            TBox1.Text = "";
        }

        private void Check1_Checked(object sender, RoutedEventArgs e)
        {
            Button1.Background = new SolidColorBrush(Colors.Blue);
            Button1.Content = "Click me Handsome boy";
        }

        private void Check1_Unchecked(object sender, RoutedEventArgs e)
        {
            Button1.Background = new SolidColorBrush(Colors.Chocolate);
            Button1.Content = "Click me Ugly boy";
        }

        private void Radio1_Checked(object sender, RoutedEventArgs e)
        {
            TBlock1.Text = "여자";
        }

        private void Radio2_Checked(object sender, RoutedEventArgs e)
        {
            TBlock1.Text = "남자";
        }
    }
}
