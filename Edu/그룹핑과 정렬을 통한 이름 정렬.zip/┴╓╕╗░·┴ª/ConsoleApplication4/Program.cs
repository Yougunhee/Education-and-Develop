﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] name = {"차민지","김병조","심재민","유건희","김동준","배성현","손명준","성현우","최원혁","허고운","최동준","윤정호","유동연","김상우","김용환"};
            var result = from c in name
                         orderby c
                         group c by c[0] into groups
                         orderby groups.Count() descending
                         select groups;

            int b = result.Count();
            Console.WriteLine("총 성의 개수는 " + b + " 개");
            foreach(IGrouping<char,string> groups in result)
            {
                int a = groups.Count();
                Console.WriteLine(groups.Key+"("+a+"명)");
                foreach(string n in groups)
                {
                    Console.WriteLine("└─"+n.Remove(0,1));
                }
            } 
        }
    }
}
