﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Grade
    {
        public string subject;
        public int score;
    }
    class Program
    {
        static void Main(string[] args)
        {
            Grade[] grade =
            {
                new Grade { subject = "국어",score=80 },
                new Grade { subject = "수학",score=99 },
                new Grade { subject ="영어",score=72},
                new Grade { subject="물리",score=68},
                new Grade { subject="화학",score=98 },
                new Grade { subject="중국어",score=84 },
                new Grade { subject="공업수학",score=100}
            };
            var result1 = from c in grade
                         orderby c.score descending
                        group c by (c.score / 10) into groups
                        select groups;
                        //select c.score;

            var result2 = from c in grade
                         orderby c.score ascending
                         group c by (c.score/10) into groups
                         select groups;
            int a=0;
            Console.WriteLine("<TOP 3>");

            foreach (IGrouping<int, Grade> groups in result1)
            {
                //foreach(int name in result1)
                foreach(Grade name in groups)
                {
                    if (a < 3)
                    {
                        Console.WriteLine(name.subject + " : " + name.score + "점");
                    }
                    if(a==3) Console.WriteLine("<90점까지 필요점수>");
                    if(a>=3)
                    {
                        Console.WriteLine(name.subject + " : " + (90 - name.score) + "점");
                    }
                    a++;
                }
            }
            a = 0;
            foreach (IGrouping<int,Grade> groups in result2)
            {
                foreach (Grade name in groups)
                {
                    if (a == 0)
                    {
                        Console.WriteLine((name.score / 10)*10 + "점대");
                        a++;
                    }
                    Console.WriteLine(name.subject+" : " + name.score+"점");
                }
                a = 0;
            }
        }
    }
}
