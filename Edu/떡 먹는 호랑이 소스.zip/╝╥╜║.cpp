#include <stdio.h>

int day, getsu, first, sec;
int amount[30];

void date()
{
	int i, j;
	amount[0] = getsu;
	for (i = getsu / 2; i<getsu; i++) {
		amount[1] = i;
		for (j = 2; j<day; j++) {
			if (j<day && amount[j - 2] - amount[j - 1] <0)break;
			if (amount[j - 2] - amount[j - 1]>amount[j - 3])break;
			amount[j] = amount[j - 2] - amount[j - 1];

		}
		if (amount[day] == 0 && amount[day - 1]>0) {
			sec = amount[day - 2];
			first = amount[day - 1];
			return;
		}
	}
}

int main()
{
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	scanf("%d %d", &day, &getsu);
	date();
	printf("%d\n%d", first, sec);
	return 0;
}