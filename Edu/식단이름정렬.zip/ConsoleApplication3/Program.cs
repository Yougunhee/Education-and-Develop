﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] foodlist = { "콩밥", "콩나물국", "어묵국", "시금치나물", "현미밥", "계란국","쌀밥", "가지나물", "숙주나물" };

            var menu = from food in foodlist
                       orderby food ascending
                       group food by (food[food.Length-1]) into groups
                       select groups;
            
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("menu" + (i+1));
                foreach (IGrouping<char, string> groups in menu)
                {
                    Console.WriteLine(groups.ElementAt(i));
                }
            }
        }
    }
}
