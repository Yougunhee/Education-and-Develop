#include <stdio.h>

int fac(int r)
{
    if(r==1) return 1;
    else return fac(r-1)*r;
}

int main()
{
    int n, m;
    scanf("%d %d", &n, &m);
    printf("%d",(fac(n+m))/(fac(n)*fac(m)));
}
