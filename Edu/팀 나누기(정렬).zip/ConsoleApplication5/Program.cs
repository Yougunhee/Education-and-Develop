﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication5
{
    class Program
    {

        delegate int testing(int a, int b);

        static void Main(string[] args)
        {
            string[] namelist = { "조성휘", "김낙환", "노민", "이상혁", "김재겸", "김병남", "김건휘", "염승우", "양준우", "이지환", "박문수", "차민지", "남인선", "원승빈", "김재하", "이태양", "천영관", "김진묵", "최원혁", "구은정", "윤석진", "장영환", "박영광", "백승민", "이다정", "양보경", "유세권", "최선우", "배재학", "이선주", "양하람", "박찬수", "박주희", "조형기", "안다현", "김찬우", "안해린" };
            var result = from c in namelist
                         orderby c ascending
                         group c by 5 into groups
                         select groups;
            int a = 1;
            foreach(IGrouping<int,string> groups in result)
            {
                foreach (string name in groups)
                {
                    if (a % 5 == 1) Console.WriteLine("\n"+ (a / 5 + 1) + "조");
                    if (a % 5 == 1) Console.Write("조장 ");
                    else if (a % 5 == 2) Console.Write("서기 ");
                    else Console.Write("팀원 ");
                    Console.WriteLine(a + "번 "+name);
                    a += 1;
                }
            }
        }
    }
}
