﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FregicHoomework
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            if (Radio1.IsChecked == true)
            {
                TBlock1.Text = "ID : " + TBox1.Text;
                TBox1.Text = "";
            }
            else if (Radio2.IsChecked == true)
            {
                TBlock2.Text = "PASSWORD : " + TBox1.Text;
                TBox1.Text = "";
            }
            else if (Radio3.IsChecked == true)
            {
                TBlock3.Text = "Gender : " + TBox1.Text;
                TBox1.Text = "";
            }
            else if (Radio4.IsChecked == true)
            {
                TBlock4.Text = "NAME : " + TBox1.Text;
                TBox1.Text = "";
            }
        }
    }
}

