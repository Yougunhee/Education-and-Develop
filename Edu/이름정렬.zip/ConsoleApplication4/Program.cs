﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] namelist = { "조성휘", "김낙환", "노민", "이상혁", "김재겸", "김병남", "김건휘", "염승우", "양준우", "이지환", "박문수", "차민지", "남인선", "원승빈", "김재하", "이태양", "천영관", "김진묵", "최원혁", "구은정", "윤석진", "장영환", "박영광", "백승민", "이다정", "양보경", "유세권", "최선우", "배재학", "이선주", "양하람", "박찬수", "박주희", "조형기", "안다현", "김찬우", "안해린" };
            var result = from c in namelist
                         orderby c ascending
                         group c by (c[0]) into groups
                         orderby groups.Count() descending
                         select groups;
            int b = result.Count();
            Console.WriteLine(b + "개");
            foreach (IGrouping<char, string> groups in result)
            {
                int a = groups.Count();
                Console.WriteLine(groups.Key + " : " + a + "명");
            }
            foreach (IGrouping<char,string> groups in result)
            {
                int a = groups.Count();
                Console.WriteLine(groups.Key + "(" + a + "명)");
                foreach (string name in groups) Console.WriteLine("└─" + name.Remove(0, 1));
            }
        }
    }
}
